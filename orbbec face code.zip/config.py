import os
import numpy as np

##########fuc_harr for get_Full_face##########
enlarge=0

###########----K--------#####################
K = np.array([
        [455.0251745115472, 0,  307.9063254761517],
        [0, 455.1358298237121,  244.0267413037374],
        [0, 0, 1]])

#################Flann_scale###################

scale=0.4


####################图片存放位置###############

##########初始读取位置###########
rgb_bmp_dir= 'E:/Obber_project/rgb_bmp/'
depth_bmp_dir= 'E:/Obber_project/depth_bmp/'

############提取人脸后的存放位置#########
rgb_png_dir= 'E:/Obber_project/rgb_png/'
depth_png_dir= 'E:/Obber_project/depth_png/'

################点云存放位置################
pcd_dir='E:/Obber_project/pcd/'

ply_dir='E:/Obber_project/ply/'

###########结果点云存放位置###########

res_dir='E:/Obber_project/result/'
