import open3d as o3d
import numpy as np
from matplotlib import pyplot as plt
import cv2 as cv
import config
import os
import time
import copy

#############  important  ###########################
############1.本程序初始rgb图片限定640*480，dep限定640*400，若不符合，请自行修改##########
############2.rgb数目和depth数目一致，且一一对应#############


# ------------------------图片预处理--------------
#################################################
# --------------BMP_TO_PNG----------------------
# --------------dep_fill------------------------
# --------------harr_get_face-------------------
##################################################

def pre_img(rgb_img, dep_img, i):
    # ----------------fill_depth------------------
    depth_new = np.zeros((480, 640,3))
    depth_new[80:480, :] = dep_img
    # rgb_DIR = config.rgb_png_dir
    # depth_DIR = config.depth_png_dir
    # cv.imwrite(rgb_DIR + str(i) + ".png", rgb_img)
    # cv.imwrite(depth_DIR + str(i) + ".png", depth_new)

    # --------------harr_GET_FACE----------------
    enlarge = config.enlarge
    gray = cv.cvtColor(rgb_img, cv.COLOR_BGR2GRAY)
    face_alt2 = cv.CascadeClassifier(cv.data.haarcascades + 'haarcascade_frontalface_alt2.xml')
    faces = face_alt2.detectMultiScale(rgb_img, scaleFactor=1.03, minNeighbors=5)

    if faces is not None:
        print("-------------------")
    print(type(faces))
    print(faces.shape)
    print(faces)
    print("-------------------")

    rgb_DIR=config.rgb_png_dir
    depth_DIR=config.depth_png_dir

    for (x, y, w, h) in faces:
        temp111 = rgb_img[y - enlarge:y + h + enlarge, x - enlarge:x + w + enlarge]
        temp222 = dep_img[y - enlarge:y + h + enlarge, x - enlarge:x + w + enlarge]

        # ---------------------save results------------

        cv.imwrite(rgb_DIR + str(i) + ".png", temp111)
        cv.imwrite(depth_DIR + str(i) + ".png", temp222)
    # cv.imshow("pic",temp111)
    # cv.waitKey(0)


# -------------------------------rgb_depth for cloud OPEN #3D-------
def get_cloud(color_raw, dep_raw, i, col, row):
    # rgbd_image = o3d.geometry.RGBDImage.create_from_color_and_depth(color_raw, dep_raw,
    #                                                                 convert_rgb_to_intensity=False)

    rgbd_image = o3d.geometry.RGBDImage.create_from_redwood_format(color_raw, dep_raw,
                                                                    convert_rgb_to_intensity=False)

    # print(rgbd_image)
    #
    # plt.subplot(1, 2, 1)
    # plt.title('Redwood grayscale image')
    # plt.imshow(rgbd_image.color)
    # plt.subplot(1, 2, 2)
    # plt.title('Redwood depth image')
    # plt.imshow(rgbd_image.depth)
    # plt.show()

    K = config.K
    inter = o3d.camera.PinholeCameraIntrinsic()
    inter.set_intrinsics(col, row, K[0][0], K[1][1], K[0][2], K[1][2])
    pcd = o3d.geometry.PointCloud().create_from_rgbd_image(
        rgbd_image, inter)

    # Flip it, otherwise the pointcloud will be upside down
    # pcd.transform([[1, 0, 0, 0], [0, -1, 0, 0], [0, 0, -1, 0], [0, 0, 0, 1]])

    # ------------save_results-------------------------------

    o3d.io.write_point_cloud("E:/Obber_project/pcd/" + str(i) + ".pcd", pcd)
    # o3d.visualization.draw_geometries([pcd])

#------------------------------rgb_depth for cloud by self----------

class point_cloud_generator():

    def __init__(self, rgb_file, depth_file, save_ply, camera_intrinsics = [config.K[0][0], config.K[1][1], config.K[0][2], config.K[1][2]]):
        self.rgb_file = rgb_file
        self.depth_file = depth_file
        self.save_ply = save_ply

        self.rgb = cv.imread(rgb_file,1)
        self.depth = cv.imread(self.depth_file, 0)

        print("your depth image shape is:", self.depth.shape)
        print("your depth image shape is:", self.rgb.shape)

        self.width = self.rgb.shape[1]
        self.height = self.rgb.shape[0]

        self.camera_intrinsics = camera_intrinsics
        # self.depth_scale = 1000

        self.depth_scale=1

    def compute(self):
        t1 = time.time()

        depth = np.asarray(self.depth, dtype=np.uint16).T
        # depth[depth==65535]=0
        self.Z = depth / self.depth_scale
        fx, fy, cx, cy = self.camera_intrinsics

        X = np.zeros((self.width, self.height))
        Y = np.zeros((self.width, self.height))
        for i in range(self.width):
            X[i, :] = np.full(X.shape[1], i)

        self.X = ((X - cx / 2) * self.Z) / fx
        for i in range(self.height):
            Y[:, i] = np.full(Y.shape[0], i)
        self.Y = ((Y - cy / 2) * self.Z) / fy

        data_ply = np.zeros((6, self.width * self.height))
        data_ply[0] = self.X.T.reshape(-1)
        data_ply[1] = -self.Y.T.reshape(-1)
        data_ply[2] = -self.Z.T.reshape(-1)
        img = np.array(self.rgb, dtype=np.uint8)
        data_ply[3] = img[:, :, 2:3].reshape(-1)
        data_ply[4] = img[:, :, 1:2].reshape(-1)
        data_ply[5] = img[:, :, 0:1].reshape(-1)
        self.data_ply = data_ply
        t2 = time.time()
        print('calcualte 3d point cloud Done.', t2 - t1)

    def write_ply(self):
        start = time.time()
        float_formatter = lambda x: "%.4f" % x
        points = []
        for i in self.data_ply.T:
            points.append("{} {} {} {} {} {} 0\n".format
                          (float_formatter(i[0]), float_formatter(i[1]), float_formatter(i[2]),
                           int(i[3]), int(i[4]), int(i[5])))

        file = open(self.save_ply, "w")
        file.write('''ply
        format ascii 1.0
        element vertex %d
        property float x
        property float y
        property float z
        property uchar red
        property uchar green
        property uchar blue
        property uchar alpha
        end_header
        %s
        ''' % (len(points), "".join(points)))
        file.close()

        end = time.time()
        print("Write into .ply file Done.", end - start)

    def show_point_cloud(self):
        pcd = o3d.io.read_point_cloud(self.save_ply)
        o3d.visualization.draw([pcd])

def get_cloud_self(color_dir,depth_dir,cloud_dir):
    camera_intrinsics = [config.K[0][0], config.K[1][1], config.K[0][2], config.K[1][2]]

    a = point_cloud_generator(rgb_file=color_dir,
                              depth_file=depth_dir,
                              save_ply=cloud_dir,
                              camera_intrinsics=camera_intrinsics
                              )
    a.compute()
    a.write_ply()


# ----------------get_R_T----------------------------------
##########################################################
# ----------------sift------------------------------------
def extract_features(image):
    sift = cv.xfeatures2d.SIFT_create(0, 3, 0.04, 10)

    key_points, descriptor = sift.detectAndCompute(cv.cvtColor(image, cv.COLOR_BGR2GRAY), None)

    return np.array(key_points), np.array(descriptor)


####################
####FLANN特征匹配
###################
def match_features(query, train):
    ####
    scale = config.scale
    ######
    if query.dtype is not 'float32':
        query = query.astype('float32')
    if train.dtype is not 'float32':
        train = train.astype('float32')
    index_params = dict(algorithm=1, trees=5)
    search_params = dict(checks=50)  # 指定递归次数
    flann = cv.FlannBasedMatcher(index_params, search_params)
    matches = flann.knnMatch(query, train, k=2)
    good_matches = []
    for m, n in matches:
        if m.distance < scale * n.distance:
            good_matches.append(m)
    return np.array(good_matches)


####################################
##利用基础矩阵F求两幅图像间的R，T
##################################
def get_transform(key_points1, key_points2):
    K = config.K
    f = (K[0][0] + K[1][1]) / 2
    light_center = (K[0][2], K[1][2])

    F, mask = cv.findEssentialMat(key_points1, key_points2, f, light_center, cv.RANSAC, 0.999, 1.0)
    Mean_K = np.array([[f, 0, light_center[0]],
                       [0, f, light_center[1]],
                       [0, 0, 1]])
    _, R, T, mask = cv.recoverPose(F, key_points1, key_points2, Mean_K, mask)

    return R, T


def get_matched_points(kp1, kp2, matches):
    src_kps = np.asarray([kp1[m.queryIdx].pt for m in matches])
    dst_kps = np.asarray([kp2[m.trainIdx].pt for m in matches])
    return src_kps, dst_kps


def get_R_T(img1, img2):
    kp1, des1 = extract_features(img1)
    kp2, des2 = extract_features(img2)

    matches = match_features(des1, des2)

    src_kps, dst_kps = get_matched_points(kp1, kp2, matches)

    R, T = get_transform(src_kps, dst_kps)

    return R, T

def draw_registration_result(source, target, transformation):
    source_temp = copy.deepcopy(source)
    target_temp = copy.deepcopy(target)
    source_temp.paint_uniform_color([1, 0.706, 0])
    target_temp.paint_uniform_color([0, 0.651, 0.929])
    source_temp.transform(transformation)
    o3d.visualization.draw_geometries([source_temp, target_temp],
                                      zoom=0.4459,
                                      front=[0.9288, -0.2951, -0.2242],
                                      lookat=[1.6784, 2.0612, 1.4451],
                                      up=[-0.3402, -0.9189, -0.1996])

def Rotate_translate_pcd(pcd,R,T):
    pcd1=copy.deepcopy(pcd)
    pcd1.rotate(R)
    pcd1.translate(T,relative=True)
    return pcd1

########################################ICP-------- 多视角点云配准
# 多视角配准是在全局空间中对齐多个几何形状的过程。比较有代表性的是，输入是一组几何形状 { P i }
# （可以是点云或者RGBD图像）。输出是一组刚性变换{ T i }
# 变换后的点云 { T i P i }可以在全局空间中对齐。

# 输入
# 第一部分是从三个文件中读取三个点云数据，这三个点云将被降采样和可视化，可以看出他们三个是不对齐的。
def load_point_clouds(voxel_size):
    pcds = []
    ply_dir=config.ply_dir
    for i in range(3):
        pcd = o3d.io.read_point_cloud(ply_dir+"%d.ply" % i)

        # pcd = o3d.io.read_point_cloud("C:/Users/User/Desktop/Obber_project/ply/%d.ply"  % i)


        # o3d.visualization.draw_geometries([pcd])
        pcd_down = pcd.voxel_down_sample(voxel_size=voxel_size)
        pcds.append(pcd_down)

        # print(type(pcd_down))
        # print(pcd_down)
        # print("---------77777----------")
        # pcds.append(pcd)

    return pcds

def pairwise_registration(source, target, max_correspondence_distance_coarse,
                      max_correspondence_distance_fine,voxel_size):
    print("Apply point-to-plane ICP")

    target.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=voxel_size * 2.0, max_nn=30))############法线

    icp_coarse = o3d.pipelines.registration.registration_icp(
        source, target, max_correspondence_distance_coarse, np.identity(4),
        o3d.pipelines.registration.TransformationEstimationPointToPlane())
    icp_fine = o3d.pipelines.registration.registration_icp(
        source, target, max_correspondence_distance_fine,
        icp_coarse.transformation,
        o3d.pipelines.registration.TransformationEstimationPointToPlane())
    transformation_icp = icp_fine.transformation
    information_icp = o3d.pipelines.registration.get_information_matrix_from_point_clouds(
        source, target, max_correspondence_distance_fine,
        icp_fine.transformation)
    return transformation_icp, information_icp


def full_registration(pcds, max_correspondence_distance_coarse,
                      max_correspondence_distance_fine,voxel_size):
    pose_graph = o3d.pipelines.registration.PoseGraph()
    odometry = np.identity(4)
    pose_graph.nodes.append(o3d.pipelines.registration.PoseGraphNode(odometry))
    n_pcds = len(pcds)
    for source_id in range(n_pcds):
        for target_id in range(source_id + 1, n_pcds):
            transformation_icp, information_icp = pairwise_registration(
                pcds[source_id], pcds[target_id], max_correspondence_distance_coarse,
                      max_correspondence_distance_fine,voxel_size)
            print("Build o3d.pipelines.registration.PoseGraph")
            if target_id == source_id + 1:  # odometry case
                odometry = np.dot(transformation_icp, odometry)
                pose_graph.nodes.append(
                    o3d.pipelines.registration.PoseGraphNode(np.linalg.inv(odometry)))
                pose_graph.edges.append(
                    o3d.pipelines.registration.PoseGraphEdge(source_id,
                                                             target_id,
                                                             transformation_icp,
                                                             information_icp,
                                                             uncertain=False))
            else:  # loop closure case
                pose_graph.edges.append(
                    o3d.pipelines.registration.PoseGraphEdge(source_id,
                                                             target_id,
                                                             transformation_icp,
                                                             information_icp,
                                                             uncertain=True))
    return pose_graph

###################--------------------统计滤波过滤，只保留人脸--------------
def Statistical_filtering(pcd):
    print("->正在进行统计滤波...")
    num_neighbors = 50  # K邻域点的个数
    std_ratio = 0.001  # 标准差乘数
    # 执行统计滤波，返回滤波后的点云sor_pcd和对应的索引ind
    sor_pcd, ind = pcd.remove_statistical_outlier(num_neighbors, std_ratio)
    # sor_pcd.paint_uniform_color([0, 0, 1])
    # print("统计滤波后的点云：", sor_pcd)
    # sor_pcd.paint_uniform_color([0, 0, 1])
    # 提取噪声点云
    sor_noise_pcd = pcd.select_by_index(ind, invert=True)
    print("噪声点云：", sor_noise_pcd)
    sor_noise_pcd.paint_uniform_color([1, 0, 0])
    # ===========================================================

    # 可视化统计滤波后的点云和噪声点云
    o3d.visualization.draw_geometries([sor_pcd, sor_noise_pcd])
    o3d.visualization.draw_geometries([sor_pcd])
    return sor_pcd


######---------------------泊松曲面重建---------------------------

def Poisson_surface(pcd):
    print('run Poisson surface reconstruction')
    radius = 0.001  # 搜索半径
    max_nn = 30  # 邻域内用于估算法线的最大点数
    pcd.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius, max_nn))  # 执行法线估计

    with o3d.utility.VerbosityContextManager(o3d.utility.VerbosityLevel.Debug) as cm:
        mesh, densities = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(pcd, depth=8)
    print(mesh)
    o3d.visualization.draw_geometries([mesh])

    return mesh


def main():
    # ----------------原始BMP图片读取---------------------
    ###################################################
    rgb_dir = config.rgb_bmp_dir
    rgb_names = os.listdir(rgb_dir)
    rgb_names = sorted(rgb_names)

    depth_dir = config.depth_bmp_dir
    depth_names = os.listdir(depth_dir)
    depth_names = sorted(depth_names)

    print("$$$$$$$$$$$$$$$$")
    print(len(rgb_names))
    print(rgb_names)

    for i in range(len(rgb_names)):
        rgb_names[i] = rgb_dir + rgb_names[i]
        depth_names[i] = depth_dir + depth_names[i]
        rgb_img = cv.imread(rgb_names[i])
        depth_img = cv.imread(depth_names[i])
        ####--------------------补全深度图并截取人脸-------------------
        print("$$$$$$$$$$$$$$$$$$$$" + str(i) + "####################")
        pre_img(rgb_img, depth_img, i)

    ##################################-----------------求RT手动旋转点云，效果很差，故打掉--------------------
    # R_all = []
    # T_all = []
    # ###############原图求RT，特征点更多，更准确######
    #
    # for i in range(len(rgb_names) - 1):
    #
    #     rgb_img1 = cv.imread(rgb_names[i])
    #     rgb_img2 = cv.imread(rgb_names[i + 1])
    #     ####-----------------------在原始图像求R，T，速度慢，但特征点多，结果可靠-----------
    #     if i==0:
    #         R, T = get_R_T(rgb_img1, rgb_img2)
    #     else:
    #         R, T = get_R_T(rgb_img2, rgb_img1)
    #     R_all.append(R)
    #     T_all.append(T)

    # ------------------预处理好的人脸图像，得到点云-------------------
    rgb_dir_re = config.rgb_png_dir
    rgb_names_re = os.listdir(rgb_dir_re)
    rgb_names_re = sorted(rgb_names_re)

    depth_dir_re = config.depth_png_dir
    depth_names_re = os.listdir(depth_dir_re)
    depth_names_re = sorted(depth_names_re)

    cloud_ply_DIR=config.ply_dir

    for i in range(len(rgb_names_re)):
        rgb_names_re[i] = rgb_dir_re + rgb_names_re[i]
        depth_names_re[i] = depth_dir_re + depth_names_re[i]

        #########-----------------open3D_cloud----------------------------
        # rgb_get_col = cv.imread(rgb_names_re[i])
        # col, row, _ = rgb_get_col.shape
        # rgb_img_re = o3d.io.read_image(rgb_names_re[i])
        # depth_img_re = o3d.io.read_image(depth_names_re[i])
        # get_cloud(rgb_img_re, depth_img_re, i, col, row)

        #########----------------get_cloud_self--------------------------

        cloud_ply_DIR_re=cloud_ply_DIR+str(i)+'.ply'
        get_cloud_self(rgb_names_re[i],depth_names_re[i],cloud_ply_DIR_re)

    voxel_size = 0.02
    pcds_down = load_point_clouds(voxel_size)
    print("Full registration ...")
    max_correspondence_distance_coarse = voxel_size * 15
    max_correspondence_distance_fine = voxel_size * 1.5
    with o3d.utility.VerbosityContextManager(o3d.utility.VerbosityLevel.Debug) as cm:
        pose_graph = full_registration(pcds_down,
                                       max_correspondence_distance_coarse,
                                       max_correspondence_distance_fine,voxel_size)
    # Open3d使用函数global_optimization进行姿态图估计，可以选择两种类型的优化算法，分别是GlobalOptimizationGaussNewton和GlobalOptimizationLevenbergMarquardt。

    # GlobalOptimizationOption定于了两个参数。max_correspondence_distance定义了对应阈值。edge_prune_threshold是修剪异常边缘的阈值。reference_node是被视为全局空间的节点ID。
    print("Optimizing PoseGraph ...")
    option = o3d.pipelines.registration.GlobalOptimizationOption(
        max_correspondence_distance=max_correspondence_distance_fine,
        edge_prune_threshold=0.25,
        reference_node=0)
    with o3d.utility.VerbosityContextManager(o3d.utility.VerbosityLevel.Debug) as cm:
        o3d.pipelines.registration.global_optimization(
            pose_graph, o3d.pipelines.registration.GlobalOptimizationLevenbergMarquardt(),
            o3d.pipelines.registration.GlobalOptimizationConvergenceCriteria(), option)
    # 全局优化在姿态图上执行两次。
    # 第一遍将考虑所有边缘的情况优化原始姿态图的姿态，并尽量区分不确定边缘之间的错误对齐。这些错误对齐将会产生小的 line process weights，他们将会在第一遍被剔除。
    # 第二遍将会在没有这些边的情况下运行，产生更紧密地全局对齐效果。在这个例子中，所有的边都将被考虑为真实的匹配，所以第二遍将会立即终止。

    # 可视化操作
    # 使用```draw_geometries``函数可视化变换点云。
    print("Transform points and display")
    for point_id in range(len(pcds_down)):
        print(pose_graph.nodes[point_id].pose)
        pcds_down[point_id].transform(pose_graph.nodes[point_id].pose)
    #o3d.visualization.draw_geometries(pcds_down)

    # 得到合并的点云
    # PointCloud是可以很方便的使用+来合并两组点云成为一个整体。
    # 合并之后，将会使用voxel_down_sample进行重新采样。建议在合并之后对点云进行后处理，因为这样可以减少重复的点后者较为密集的点。
    pcds = load_point_clouds(voxel_size)
    pcd_combined = o3d.geometry.PointCloud()
    for point_id in range(len(pcds)):
        pcds[point_id].transform(pose_graph.nodes[point_id].pose)
        pcd_combined += pcds[point_id]

    pcd_combined_down = pcd_combined.voxel_down_sample(voxel_size=0.02)

    # pcd_combined_down = pcd_combined
    save_res=config.res_dir
    o3d.io.write_point_cloud(save_res+"res.pcd", pcd_combined_down)

    o3d.visualization.draw_geometries([pcd_combined_down])

    sor_pcd=Statistical_filtering(pcd_combined_down)

    o3d.io.write_point_cloud(save_res + "res_after.pcd", sor_pcd)


    mesh=Poisson_surface(sor_pcd)

    o3d.io.write_triangle_mesh(save_res + "Poisson.ply", mesh)












if __name__ == '__main__':
    main()
